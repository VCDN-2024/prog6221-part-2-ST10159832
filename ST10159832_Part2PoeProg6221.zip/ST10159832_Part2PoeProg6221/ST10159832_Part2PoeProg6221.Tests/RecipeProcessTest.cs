﻿using Microsoft.VisualStudio.TestTools.UnitTesting;
using System;

namespace ST10159832_Part2PoeProg6221.Tests
{       //https://learn.microsoft.com/en-us/dotnet/core/testing/unit-testing-with-dotnet-test. 
        // website used to create unit test project

    [TestClass]
    public class RecipeProcessTest
    {
        [TestMethod]
        public void TestTotalCalories()
        {
            
            Recipe recipe = new Recipe("Test Recipe");
            recipe.AddIngredient(new Ingredient("Sugar", 1, "cup", 774, "Carbohydrates"));
            recipe.AddIngredient(new Ingredient("Butter", 0.5, "cup", 814, "Fats"));

           
            int totalCalories = recipe.CalculateTotalCalories();

           
            Assert.AreEqual(1588, totalCalories);
        }

        [TestMethod]
        public void TestCaloriesExceedNotification()
        {
           
            RecipeManager manager = new RecipeManager();
            bool eventFired = false;
            manager.RecipeCaloriesExceeded += (name, calories) => { eventFired = true; };

            Recipe recipe = new Recipe("High Calorie Recipe");
            recipe.AddIngredient(new Ingredient("Sugar", 2, "cup", 1548, "Carbohydrates"));
            recipe.AddIngredient(new Ingredient("Butter", 1, "cup", 1628, "Fats"));

            
            manager.AddRecipe(recipe);
            manager.CheckRecipeCalories(recipe);

          
            Assert.IsTrue(eventFired);
        }
    }
}
