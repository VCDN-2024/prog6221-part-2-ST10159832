﻿namespace ST10159832_Part2PoeProg6221
{
    internal class Program
    {
        static void Main(string[] args)
        {
            //this intialises the layout class and will call the method to display the layout 
            Layout layout = new Layout();
            layout.ProgramLayout();
        }
    }
}

// code attribution: Troelsen, A. and Japikse, P. (2022). Pro C# 10 with .NET 6. Apress.