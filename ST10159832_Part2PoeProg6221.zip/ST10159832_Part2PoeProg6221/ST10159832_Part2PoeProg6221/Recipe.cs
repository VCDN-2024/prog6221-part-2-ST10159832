﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ST10159832_Part2PoeProg6221
{
    internal class Recipe // this class is where the calories of the recipe will be calculated 
    {
        public string Name { get; set; } //https://youtu.be/vQzREQUhGSA?si=ohJK0BljRETW1sTZ   video used to create the list and initailise the list
        public List<Ingredient> Ingredients { get; set; } = new List<Ingredient>(); //https://youtu.be/vQzREQUhGSA?si=ohJK0BljRETW1sTZ   video used to create the list and initailise the list
        public List<string> Steps { get; set; } = new List<string>(); //https://youtu.be/vQzREQUhGSA?si=ohJK0BljRETW1sTZ   video used to create the list and initailise the list

        // this method will essentially calculate the total calories of the recipe
        public int CalculateTotalCalories()//https://youtu.be/VQpfdMJX4Cw?si=nKVf79QGLR9GIYUi video used to calculate the total sum of calories
        {  //https://stackoverflow.com/questions/18824761/c-sharp-how-to-get-sum-of-the-values-from-list. website used to caluclate the total sum of calories 
            int totalCalories = 0;
            foreach (var ingredient in Ingredients)
            {
                totalCalories += ingredient.Calories;
            }
            return totalCalories;
        }
    }
}
