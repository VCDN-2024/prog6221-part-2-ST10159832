﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ST10159832_Part2PoeProg6221
{
    internal class RecipeProcess
    {
        // this is the list that will store the recipes 
        List<Recipe> recipes = new List<Recipe>(); //https://youtu.be/vQzREQUhGSA?si=ohJK0BljRETW1sTZ   video used to create the list and initailise the list

        // this method basiaclly allows for users to add a recipe 
        public void AddRecipe()
        {
            Recipe recipe = new Recipe();
            Console.WriteLine("Please enter the name of the recipe: ");
            recipe.Name = Console.ReadLine();

            // this allows for the storing of the ingredients 
            recipe.Ingredients = new List<Ingredient>(); //https://youtu.be/vQzREQUhGSA?si=ohJK0BljRETW1sTZ   video used to create the list and initailise the list
            Console.WriteLine("Please enter the number of ingredients used in the recipe: ");
            int numIngredients = int.Parse(Console.ReadLine());
            for (int i = 0; i < numIngredients; i++)
            {
                Ingredient ingredient = new Ingredient(); //https://youtu.be/vQzREQUhGSA?si=ohJK0BljRETW1sTZ   video used to create the list and initailise the list
                Console.WriteLine($"Enter ingredient {i + 1} name: ");
                ingredient.Name = Console.ReadLine();
                Console.WriteLine($"Enter quantity for {ingredient.Name}: ");
                ingredient.Quantity = double.Parse(Console.ReadLine());
                Console.WriteLine($"Enter unit for {ingredient.Name}:");
                ingredient.Unit = Console.ReadLine();
                Console.WriteLine($"Enter calories for {ingredient.Name}: ");
                ingredient.Calories = int.Parse(Console.ReadLine());
                Console.WriteLine($"Enter food group for {ingredient.Name}: ");
                ingredient.FoodGroup = Console.ReadLine();
                recipe.Ingredients.Add(ingredient);
            }

            // this stores the steps of the recipe 
            recipe.Steps = new List<string>(); //https://youtu.be/vQzREQUhGSA?si=ohJK0BljRETW1sTZ   video used to create the list and initailise the list
            Console.WriteLine("Enter the number of steps: ");
            int numSteps = int.Parse(Console.ReadLine());
            for (int i = 0; i < numSteps; i++)
            {
                Console.WriteLine($"Enter step {i + 1}: ");
                recipe.Steps.Add(Console.ReadLine());
            }

            recipes.Add(recipe);
        }

        // this method is used to display the list of all the recipes in alphabetical order 
        public void DisplayRecipes()//https://youtu.be/tbgtcUduExI?si=TmJoZqbfREWWIlv1 video used to sort out list alphabetically 
        {                           //https://youtu.be/e0H-VVpa184?si=0mtwMjMZpShjkrvk  another video used to sort list out alphabetically 
            try
            {
                Console.WriteLine("List of Recipes: ");
                var sortedRecipes = recipes.OrderBy(r => r.Name).ToList();
                foreach (var recipe in sortedRecipes)
                {
                    Console.WriteLine(recipe.Name);
                }
            }
            catch (Exception ex)
            {
                Console.WriteLine($"An error occurred while displaying recipes: {ex.Message}");
            }
        }

        // this method is used for searching for and displaying the recipe that was searched for 
        public void DisplayRecipe(string recipeName)
        {
            try
            {
                Recipe recipe = recipes.FirstOrDefault(r => r.Name == recipeName);
                if (recipe != null)
                {
                    Console.WriteLine($"Recipe: {recipe.Name}");
                    Console.WriteLine("Ingredients:");
                    foreach (var ingredient in recipe.Ingredients)
                    {
                        Console.WriteLine($"{ingredient.Quantity} {ingredient.Unit} of {ingredient.Name}");
                        Console.WriteLine($"Calories: {ingredient.Calories}");
                    }
                    Console.WriteLine("Steps:");
                    foreach (var step in recipe.Steps)
                    {
                        Console.WriteLine(step);
                    }
                }
                else
                {
                    Console.WriteLine("The recipe not found");
                }
            }
            catch (Exception ex)
            {
                Console.WriteLine($"An error occurred while displaying the recipe: {ex.Message}");
            }
        }

        // this method is used to calculate and display the total calories in a recipe entered 
        public void DisplayTotalCalories(string recipeName) //https://youtu.be/VQpfdMJX4Cw?si=nKVf79QGLR9GIYUi video used to calculate the total sum of calories
        {
            try
            {
                Recipe recipe = recipes.Find(r => r.Name == recipeName);
                if (recipe != null)
                {
                    int totalCalories = recipe.CalculateTotalCalories();
                    Console.WriteLine($"The total Calories for {recipe.Name}: {totalCalories}");
                    if (totalCalories > 300)
                    {
                        Console.WriteLine("The total calories of the recipe exceeds 300");
                    }
                }
                else
                {
                    Console.WriteLine("The recipe was not found");
                }
            }
            catch (Exception ex)
            {
                Console.WriteLine($"An error occurred while calculating and displaying total calories: {ex.Message}");
            }
        }


    }
}
